import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LeadModalComponent } from '../lead-modal/lead-modal.component';
import { LeadService } from '../../service/lead.service';
import { CommonService } from '../../service/common.service';
import { NotifierService } from 'angular-notifier';
import { Router } from '@angular/router';
import {Location} from '@angular/common';

@Component({
  selector: 'app-leadlist',
  templateUrl: './leadlist.component.html',
  styleUrls: ['./leadlist.component.css']
})
export class LeadlistComponent implements OnInit {

  @ViewChild('deletemodal') deleteModal:any;
  @ViewChild('bulkUpload') bulkTask:any;

  limit: number = 10;
  offset: number = 0;
  userId: any;
  userType: any;
  clientId: any;
  allLeadArray: any = [];
  selectedVal: number = 10;
  deleteLeadId = "" as any;
  contactName = "";
  orgName = "";
  title = "";
  phone = "";
  email = "";
  leadStatus = "";
  owner = "";

  //---------------- For Bulk Inser-----------//

  bulkFile = "";
  uploadBulkFile = "";

  public pageList: Array<any> = [
      {name: '10', value: '10'},
      {name: '15', value: '15'},
      {name: '20', value: '20'},
      {name: '30', value: '30'},
      {name: '50', value: '50'}
  ]

  isdisable: boolean = false;
  isPrevious: boolean = true;
  constructor(private ngModelService:NgbModal,private leadRest : LeadService, private common : CommonService,
              private notifier: NotifierService, private router: Router, private _location: Location) {
      
      this.common.addLeadSubject.subscribe((res) => {
        this.getAllLead();
      });
      // this.commonService.Subject.subscribe((res:any)=>{
      //   this.getTaskManagementList();
  
      // })
  }

  ngOnInit(): void {
    this.userId = this.common.getuserId();
    this.userType = this.common.getUserType();
    this.clientId = this.common.getClientId()
    this.getAllLead();
  }
  getAllLead(): any {
    this.common.spinnerShow();
    let param  = {
      'limit' : this.limit,
      'offset' :this.offset.toString(),
      'contactName' : this.contactName,
      'orgName' : this.orgName,
      'title' : this.title,
      'phone' : this.phone,
      'email' : this.email,
      'leadStatus' : this.leadStatus,
      'owner' : this.owner
    };
    console.log("Request for lead list>>>>>>>",param);
    this.leadRest.getAllLeadList(param).subscribe((res: any) => {
      console.log("All Leads List:::::::::::::::-",res);
      this.common.spinnerHide();
      if ((res.success) && (res.status == 200)) {
        this.allLeadArray = [];
        if (res.response.data.length == 0) {
          this.offset = this.offset > 0 ? this.offset - this.limit : this.offset;
          this.isdisable = true;
      } else {
        this.allLeadArray = res.response.data;
        // console.log("lead>>>>>>>>>>>>",this.allLeadArray)
        this.isdisable = res.response.data.length < this.limit ? true : false;
      }
        
      }
    });
  }
  addLead() : any {
    this.common.isAdd = true;
    this.ngModelService.open(LeadModalComponent , {centered: true, size: 'xl'});
    setTimeout(() => {
      const elem = document.getElementsByClassName('modal');
      if (elem) {
        elem[0].classList.add('addContactModal')
      }
    }, 200);
  }
  gotoDetailsPage(leadId: any): any {
    this.router.navigate(['pages/lead-details/' + leadId]);
  }
  editLead(leadId : any): any {
    this.common.spinnerShow();
    this.common.isAdd = false;
    this.ngModelService.open(LeadModalComponent , {centered: true, size: 'xl'});
    setTimeout(() => {
      const elem = document.getElementsByClassName('modal');
      if (elem) {
        elem[0].classList.add('addContactModal')
      }
    }, 200);
    this.common.leadId = leadId;
  }
  deleteLead(leadId: any): any {
    this.deleteOpenModal();
    this.deleteLeadId = leadId;
  }

  changepagelimit(e: any) {

    this.limit = Number(e.target.value);
    this.getAllLead();

}

previous() {
    this.isdisable = false;
    this.offset = this.offset > 0 ? this.offset - this.limit : 0;
    this.offset = this.offset < 0 ? 0 : this.offset;
    this.getAllLead();
    if (this.offset <= 0) {
        this.isPrevious = true;
    }

}

next() {
    this.isPrevious = false;
    this.offset = this.offset + this.limit;
    this.getAllLead();
}
deleteOpenModal(): void {
  this.ngModelService.open(this.deleteModal, {centered: true, size: 'sm'})
}
closeModal(){
  this.ngModelService.dismissAll();
}

delete(){
  let param = {
    "userId" : this.userId,
    "leadId" : this.deleteLeadId
  };
  this.leadRest.deleteLead(param).subscribe((res:any) => {
    if ((res.success) && (res.status == 200)) {
      this.getAllLead();
      this.closeModal();
      this.notifier.notify('success',res.message);
    } else{
      this.notifier.notify('error',res.message);
    }
  });
}
searchByName(event:any){
  if(event.target.value.length >= 3){
    this.contactName = event.target.value;
    this.getAllLead();
  }
  if(event.target.value.length == 0){
    this.contactName = "";
    this.getAllLead();
  }
}

searchByOrganization(event:any){
  if(event.target.value.length >= 3){
    this.orgName = event.target.value;
    this.getAllLead();
  }
  if(event.target.value.length == 0){
    this.orgName = "";
    this.getAllLead();
  }
}

searchByTitle(event:any){
  if(event.target.value.length >= 3){
    this.title = event.target.value;
    this.getAllLead();
  }
  if(event.target.value.length == 0){
    this.title = "";
    this.getAllLead();
  }
}

searchByPhone(event:any){
  if(event.target.value.length >= 3){
    this.phone = event.target.value;
    this.getAllLead();
  }
  if(event.target.value.length == 0){
    this.phone = "";
    this.getAllLead();
  }
}

searchByEmail(event:any){
  if(event.target.value.length >= 3){
    this.email = event.target.value;
    this.getAllLead();
  }
  if(event.target.value.length == 0){
    this.email = "";
    this.getAllLead();
  }
}

searchByLeadStatus(event:any){
  if(event.target.value == "All"){
    this.leadStatus = "";
    this.getAllLead();
  }
  if(event.target.value == "Warm"){
    this.leadStatus = "1";
    this.getAllLead();
  }
  if(event.target.value == "Cold"){
    this.leadStatus = "2";
    this.getAllLead();
  }
  if(event.target.value == "Hot"){
    this.leadStatus = "3";
    this.getAllLead();
  }
}

searchByLeadOwner(event:any){
  if(event.target.value.length >= 3){
    this.owner = event.target.value;
    this.getAllLead();
  }
  if(event.target.value.length == 0){
    this.owner = "";
    this.getAllLead();
  }
}

//--------------For Bulk Upload----------------//

multipleUpload(){
  this.ngModelService.open(this.bulkTask,{centered:true});
}
sampleDownload(){
  window.open(this.common.downloadPath + 'leads.xlsx');
}
uploadFile(){
  const banner = document.getElementById('upload') as HTMLInputElement;
  const file: any = banner.files;
  if (file.length > 0) {
      const reader = new FileReader();
      reader.readAsDataURL(file[0]);
      reader.onload = () => {
          this.bulkFile = reader.result as string;
          console.log("bulkFile>>>>>>>>", this.bulkFile);
          const fileData = new FormData();
          fileData.append('file', file[0]);
          this.leadRest.uploadFileForBulk(fileData).subscribe((res: any) => {
              console.log("File upload res>>>>>>>>", res);
              if (res.success) {
                  this.uploadBulkFile = res.response.fileName;
                  console.log("Upload Bulk File upload>>>>>>>>>>>", this.uploadBulkFile);
                  this.notifier.notify('success', res.message);
              } else {
                  this.notifier.notify('error', res.message);
              }

          })
      }
  }

}

bulkInsert(){
  const data = {
    fileName: this.uploadBulkFile
};
console.log("Request for Bulk Upload for Task",data);
this.leadRest.bulkLeadInsert(data).subscribe((res: any) => {
    console.log("Bulk Insert >>>>>>", res);
    if (res.success) {
      this.getAllLead();
        this.closeModal();
        this.notifier.notify('success', res.message);
    } else {
        this.notifier.notify('error', res.message);
    }
})

}


}
